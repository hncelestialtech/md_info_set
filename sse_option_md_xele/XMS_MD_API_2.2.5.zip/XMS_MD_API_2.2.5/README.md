# XTS_MD_API

#### 最近更新

  版本号 v2.2.5

  更新日期 2025-09-08

#### 文件目录

├── changelog                                             `行情API 版本变动记录`\
├── README.md                                             `API readme`\                            
├── xele_md_api_demo                                      `极速行情收取demo文件夹`\
│   ├── xele_md_api                                       `API头文件和库` 
├── doc                                                   `接口文档目录`\
│   ├──  艾科朗克证券行情接口说明.pdf                     `接口文档`

#### 开发语言

   c++11

#### 编译环境

  linux （centos） 3.10.0-957.el7.x86_64

  gcc version 4.8.5 20150623 (Red Hat 4.8.5-36)

#### 运行环境

   linux系统，如果使用efvi模式侦听行情，需要安装onload驱动，推荐openonload-201811-u1
   
#### DEMO使用方法

	编译：
	执行./build.sh，会在bin目录下生成可执行文件api_demo
	
	配置文件：
	md_xele.conf

	api关键函数介绍：
	
	//创建实例
	static XeleMd* CreatInstance();
	
	//用户鉴权
	bool Login(LoginReq* login_req, LoginRsp *login_rsp, struct MulticastAddr **addrBegin);

	//初始化组播(通道)信息
	int Init(MdParam *const param, const int count); 

	//注册回调函数
	void RegisterSseSpi(XeleMdSseSpi* pSpi);

	//开始接收行情
	int Start();

	//停止接收行情
	int Stop();







